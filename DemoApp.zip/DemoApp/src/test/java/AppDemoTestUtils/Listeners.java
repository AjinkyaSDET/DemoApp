package AppDemoTestUtils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import JiniusDemoApp.AppDemoSetup;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;


public class Listeners extends AppDemoSetup implements ITestListener {
	IOSDriver driver;
	ExtentTest test;
	ExtentReports extent =  ExtentReportJinius.ExtentReportNG();
	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
	
		test= extent.createTest(result.getMethod().getMethodName());
		test.log(Status.INFO, "This Scenario has passed for given conditions and below are Snippets for the same from DemoApp");

		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		
		test.log(Status.PASS, "Test Passed");
		
		try {
			driver = (IOSDriver) result.getTestClass().getRealClass().getField("driver")
					.get(result.getInstance());
			
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		try {
			test.addScreenCaptureFromPath(getScreenshotPath(result.getMethod().getMethodName(),driver), result.getMethod().getMethodName());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		



	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		//screenshot code
           test.fail(result.getThrowable());
           test.log(Status.INFO, "This Scenario has failed due to incorrect login credentials and below are Snippets for the same from DemoApp");
		try {
			driver = (IOSDriver) result.getTestClass().getRealClass().getField("driver")
					.get(result.getInstance());
			
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		try {
			test.addScreenCaptureFromPath(getScreenshotPath(result.getMethod().getMethodName(),driver), result.getMethod().getMethodName());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
		
		
		
	}
	  private void captureScreenshot(ITestResult result) {
	        IOSDriver driver = this.driver;
	        if (driver != null) {
	            try {
	                String screenshotPath = getScreenshotPath(result.getMethod().getMethodName(), driver);
	                test.addScreenCaptureFromPath(screenshotPath, result.getMethod().getMethodName());
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        } else {
	            System.out.println("Driver is null, unable to capture screenshot");
	        }
	    }
	
        
       
	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
	
		extent.flush();
	}
//
	
}
