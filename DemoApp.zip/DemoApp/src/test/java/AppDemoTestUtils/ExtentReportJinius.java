package AppDemoTestUtils;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;

import org.openqa.selenium.devtools.v122.page.Page.CaptureScreenshotFormat;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;



public class ExtentReportJinius {
	static ExtentReports extent;
	public IOSDriver driver;
	@BeforeTest
	public static ExtentReports ExtentReportNG()
	{
		
		String path = System.getProperty("user.dir")+"//reports//index.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);	
		reporter.config().setReportName("JiniusDemoApp Automation Results");
		reporter.config().setDocumentTitle("Scenarios Results");
		
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		
		
		
		extent.setSystemInfo("Tester", "Ajinkya Godbole");
		return extent;
		}			
				
		

		
	}
	
	

