package JiniusDemoApp;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;





public class AppDemo_Scenario3 extends AppDemoSetup{
	
	
	
	@Test
    public void Scenario_3() throws InterruptedException {
        // Start Appium server
		performLogin("Jinius", "1234");
    }
        

    
    private void performLogin(String username, String password) throws InterruptedException

	
	{
		
		//code

				//System.out.println("Scenario 3 : User logged In & Is able to select the items from using search box");
				driver.findElement(AppiumBy.iOSNsPredicateString("value == \"Username\"")).sendKeys(username);
				System.out.println("      ");
				System.out.println("Scenario 3: User navigates and selects an item from the list (post login)");
				System.out.println("Message 1 : User Enters UserName");
				driver.findElement(AppiumBy.iOSNsPredicateString("value == \"Password\"")).sendKeys(password);
				System.out.println("Message 2 : User Enters UserName");
				driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeButton[`name == \"Login\"`]")).click();
				System.out.println("Message 3 : User Clicks on Login Button");
				Thread.sleep(500);
				
				
				
				
				
				driver.findElement(AppiumBy.accessibilityId("Search")).sendKeys("Item 1");
				System.out.println("Message 4 : User Enters Item Name in search box");
				Thread.sleep(500);
				String Item = driver.findElement(AppiumBy.accessibilityId("Item 1")).getText();
				driver.findElement(AppiumBy.accessibilityId("Search")).clear();
				Thread.sleep(2000);
				WebElement ele = driver.findElement(AppiumBy.accessibilityId("Item 8"));	        
		        // Prepare the parameters for the mobile:scroll command
		        Map<String, Object> params = new HashMap<>();
		        params.put("direction", "down");
		        params.put("element", ((RemoteWebElement) ele).getId());

		        // Execute the mobile:scroll command
		        driver.executeScript("mobile:scroll", params);
				
		        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				driver.findElement(AppiumBy.accessibilityId("Search")).sendKeys("Item 12");
				String Item1 = driver.findElement(AppiumBy.accessibilityId("Item 1")).getText();
				System.out.println("Message 5 : User Enters Another New Item Name in search box");
				
				
	}
	
	
}
