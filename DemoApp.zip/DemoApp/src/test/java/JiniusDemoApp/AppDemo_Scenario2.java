package JiniusDemoApp;

import java.io.File;
import java.net.URI;
import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class AppDemo_Scenario2 extends AppDemoSetup {

    

    @Test
    public void Scenario_2() throws InterruptedException 
    {
        // Start Appium server
        
        performLogin("Jini", "12345");
    }

    
    private void performLogin(String username, String password) throws InterruptedException
    {
        System.out.println("Scenario 2: User incorrect login");
        driver.findElement(AppiumBy.iOSNsPredicateString("value == \"Username\"")).sendKeys(username);
        System.out.println("Message 1: User enters incorrect Username");
        driver.findElement(AppiumBy.iOSNsPredicateString("value == \"Password\"")).sendKeys(password);
        System.out.println("Message 2: User enters incorrect Password");
        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeButton[`name == \"Login\"`]")).click();
             
        //System.out.println("Message 3: User clicks on Logged in button");
        
       // System.out.println("Message 4: User is not able to login into the application due to incorrect login credentials");
        String successLogin=driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"Details\"`]")).getText();
		Assert.assertEquals("Details", successLogin);
    }
    
    }

