package JiniusDemoApp;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.OutputType;

import org.apache.commons.io.FileUtils;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;


public class AppDemoSetup {
	
	public IOSDriver driver;
	
	@BeforeClass

	public void Setup() throws MalformedURLException, URISyntaxException, InterruptedException
	{
//		AppiumDriverLocalService service = new AppiumServiceBuilder()
//            .withAppiumJS(new File("/Users/ab02822/node_modules/appium-geckodriver/build/index.js"))
//             .withIPAddress("127.0.0.1")
//         .usingPort(4723)
//        .build();
//		//Start Appium Server
//       service.start();

        // Set desired capabilities;
           XCUITestOptions options = new XCUITestOptions()
        		 //Please give the DeviceName for the device you want to execute.
        		.setDeviceName("iPhone 15")
                //Please give the UDID for the device you want to execute.
                .setUdid("8BD50398-4B7B-4B35-8F08-2F451F94583F")
                //Set the path where it is located on your machine
                // General method to find the app/ipa location 
                //- ~/Library/Developer/Xcode/DerivedData/AppName/Build/Products/Debug-iphonesimulator/right click on app/Show package content/app
                .setApp("/Users/ab02822/Library/Developer/Xcode/DerivedData/Demo_App-atdgxsfcyzphouesougdxhnpopqs/Build/Products/Debug-iphonesimulator/Demo App.app")
                .setPlatformVersion("17.5")
              //  .setCapability(NoReset, True);
                .setWdaLaunchTimeout(Duration.ofSeconds(2000));
                
                

        // Initialize driver
       
            driver = new IOSDriver(new URI("http://127.0.0.1:4723").toURL(), options);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

           
	
	public String getScreenshotPath(String testCaseName, AppiumDriver driver) throws IOException
	{
		File source = driver.getScreenshotAs(OutputType.FILE);
		String destinationFile = System.getProperty("user.dir")+"//reports"+testCaseName+".png";
		FileUtils.copyFile(source, new File(destinationFile));
		return destinationFile;
		//1. capture and place in folder //2. extent report pick file and attach to report
		
		
		
	}
	
	
	@AfterClass(alwaysRun=true)
	public void teardown()
	{
		
		driver.quit();
		
	}

}