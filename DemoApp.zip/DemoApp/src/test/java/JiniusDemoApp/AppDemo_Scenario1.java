package JiniusDemoApp;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;


@Test


public class AppDemo_Scenario1 extends AppDemoSetup{
	
    public void Scenario_1() throws InterruptedException {
      
        
        performLogin("Jinius", "1234");
    }

    
    private void performLogin(String username, String password) throws InterruptedException


	
	{
		
		//code

				
				//Enters Correct Credentials --
				System.out.println("Scenario 1 : User Enter correct credentials for login");
				System.out.println("      ");
				driver.findElement(AppiumBy.iOSNsPredicateString("value == \"Username\"")).sendKeys(username);
				System.out.println("Message 1 : User Enters UserName");
				driver.findElement(AppiumBy.iOSNsPredicateString("value == \"Password\"")).sendKeys(password);
				System.out.println("Message 2 : User Enters Password");
				driver.findElement(AppiumBy.xpath("//XCUIElementTypeButton[@name=\"Login\"]")).click();
				Thread.sleep(2000);
				System.out.println("Message 3 : User clicks on Login Button");
				System.out.println("      ");
				String successLogin=driver.findElement(AppiumBy.iOSNsPredicateString("name == \"Search\"")).getText();
				Assert.assertEquals("Search", successLogin);
				
				
				
								
	}
	

	
	
}
